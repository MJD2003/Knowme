import React from 'react';
import { GiHamburgerMenu } from 'react-icons/gi';
import { LuCreditCard } from "react-icons/lu";

import './Navbar.css';

const Navbar = () => {
  const [toggleMenu, setToggleMenu] = React.useState(false);
  return (
    <nav className="app__navbar">
      <div className="app__navbar-logo">
        <img src="" alt="app__logo" />
      </div>
      <ul className="app__navbar-links">
        <li className="p__opensans"><a href="#home">Home</a></li>
        <li className="p__opensans"><a href="#about">About</a></li>
        <li className="p__opensans"><a href="#menu">Functions</a></li>
        <li className="p__opensans"><a href="#awards">Pricing&Plans</a></li>
        <li className="p__opensans"><a href="#contact">FindUs</a></li>
      </ul>
      <div className="app__navbar-contact">
        <a href="#login" className="p__opensans">Contact</a>
        <div />
        <a href="/" className="p__opensans">KnowMe Express</a>
      </div>
      <div className="app__navbar-smallscreen">
        <GiHamburgerMenu color="#fff" fontSize={27} onClick={() => setToggleMenu(true)} />
        {toggleMenu && (
          <div className="app__navbar-smallscreen_overlay flex__center slide-bottom">
            <LuCreditCard fontSize={27} className="overlay__close" onClick={() => setToggleMenu(false)} />
            <ul className="app__navbar-smallscreen_links">
              <li><a href="#home" onClick={() => setToggleMenu(false)}>Home</a></li>
              <li><a href="#about" onClick={() => setToggleMenu(false)}>About</a></li>
              <li><a href="#menu" onClick={() => setToggleMenu(false)}>Functions</a></li>
              <li><a href="#awards" onClick={() => setToggleMenu(false)}>Pricing&Plans</a></li>
              <li><a href="#contact" onClick={() => setToggleMenu(false)}>FindUs</a></li>
            </ul>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;